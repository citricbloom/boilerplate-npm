<?php get_header(); ?>
<main id="main" class="section section--paper"><div class="shell reading"><p class="eyebrow">404</p><h1>That page could not be found.</h1><p class="lead">Return to Polaris or talk to our team.</p><div class="actions"><a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a><a class="text-link" href="<?php echo esc_url( polaris_page_url( 'talk-to-our-team' ) ); ?>">Talk to our team</a></div></div></main>
<?php get_footer();
