=== Polaris Wellbeing ===
Contributors: polariswellbeing
Requires at least: 6.4
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later

Controlled WordPress parity theme for the approved Polaris Wellbeing v0.3.4 front-end.
Install and activate the companion Polaris Core plugin before activating this theme.
