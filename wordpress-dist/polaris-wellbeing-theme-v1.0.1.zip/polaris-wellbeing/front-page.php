<?php
if ( ! polaris_render_controlled_page( 'home' ) ) { status_header( 500 ); }
