<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header">
  <div class="shell header-inner">
    <a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Polaris Wellbeing home"><img src="<?php echo esc_url( polaris_logo_url() ); ?>" alt="" width="285" height="100"></a>
    <nav class="desktop-nav" aria-label="Primary navigation"><?php echo polaris_render_menu( 'primary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></nav>
    <button class="menu-toggle" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-navigation" data-menu-toggle><span class="menu-lines" aria-hidden="true"></span></button>
  </div>
</header>
<nav class="mobile-nav" id="mobile-navigation" aria-label="Mobile navigation" aria-hidden="true" data-mobile-nav><?php echo polaris_render_menu( 'primary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><a class="button button--wide" href="<?php echo esc_url( polaris_page_url( 'talk-to-our-team' ) ); ?>">Talk to our team</a></nav>
