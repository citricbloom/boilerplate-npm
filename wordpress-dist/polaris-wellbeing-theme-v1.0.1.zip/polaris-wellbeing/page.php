<?php
$slug = polaris_controlled_slug();
if ( $slug && polaris_render_controlled_page( $slug ) ) { return; }
get_header();
?>
<main id="main" class="section section--paper"><div class="shell reading"><?php while ( have_posts() ) : the_post(); ?><h1><?php the_title(); ?></h1><?php the_content(); ?><?php endwhile; ?></div></main>
<?php get_footer();
