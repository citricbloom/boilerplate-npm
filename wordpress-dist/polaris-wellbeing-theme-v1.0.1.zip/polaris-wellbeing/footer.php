<footer class="site-footer">
  <div class="shell">
    <div class="footer-grid">
      <div><a class="footer-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( polaris_logo_url() ); ?>" alt="" width="285" height="100"></a><p class="small"><?php echo esc_html( polaris_value( 'global_footer_blurb' ) ); ?></p></div>
      <nav class="footer-links" aria-label="Footer navigation"><?php echo polaris_render_menu( 'footer' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></nav>
    </div>
    <div class="footer-meta"><?php echo esc_html( polaris_value( 'global_footer_meta' ) ); ?> · © <?php echo esc_html( gmdate( 'Y' ) ); ?> · <a href="<?php echo esc_url( get_privacy_policy_url() ?: home_url( '/privacy-policy/' ) ); ?>">Privacy</a></div>
  </div>
</footer>
<?php if ( ! is_page( 'talk-to-our-team' ) ) : ?><a class="mobile-contact" href="<?php echo esc_url( polaris_page_url( 'talk-to-our-team' ) ); ?>">Talk to our team</a><?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
