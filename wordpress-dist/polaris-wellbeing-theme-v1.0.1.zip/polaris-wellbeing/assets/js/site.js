(() => {
  document.querySelectorAll('.header-cta').forEach(node => node.remove());
  document.querySelector('.hero-caption')?.remove();

  const toggle = document.querySelector('[data-menu-toggle]');
  const nav = document.querySelector('[data-mobile-nav]');
  const body = document.body;
  let menuWasOpened = false;

  const navFocusable = () => nav ? [...nav.querySelectorAll('a[href], button:not([disabled])')] : [];

  const setMenuState = (open, { restoreFocus = false } = {}) => {
    if (!toggle || !nav) return;
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    nav.classList.toggle('is-open', open);
    nav.setAttribute('aria-hidden', String(!open));
    nav.inert = !open;
    body.classList.toggle('nav-open', open);
    if (open) {
      menuWasOpened = true;
      window.setTimeout(() => navFocusable()[0]?.focus(), 0);
    } else if (restoreFocus && menuWasOpened) {
      toggle.focus();
    }
  };

  if (toggle && nav) {
    setMenuState(false);
    toggle.addEventListener('click', () => {
      setMenuState(toggle.getAttribute('aria-expanded') !== 'true', { restoreFocus: true });
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setMenuState(false)));
    window.addEventListener('keydown', event => {
      if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
        event.preventDefault();
        setMenuState(false, { restoreFocus: true });
      }
      if (event.key === 'Tab' && toggle.getAttribute('aria-expanded') === 'true') {
        const focusable = navFocusable();
        if (!focusable.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    });
    window.addEventListener('resize', () => {
      if (window.innerWidth >= 980) setMenuState(false);
    });
  }

  document.querySelectorAll('[data-reveal-request]').forEach(control => {
    control.addEventListener('click', event => {
      event.preventDefault();
      const panel = document.querySelector('#request-form');
      if (!panel) return;
      panel.hidden = false;
      const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      panel.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'start' });
      window.setTimeout(() => panel.querySelector('input, select, textarea')?.focus(), reducedMotion ? 0 : 450);
    });
  });

  const form = document.querySelector('[data-polaris-form]');
  if (form) {
    const phone = form.querySelector('input[name="phone"]');
    const email = form.querySelector('input[name="email"]');
    const status = form.querySelector('[data-form-status]');

    const syncContactRequirements = () => {
      const choice = form.querySelector('input[name="contact"]:checked')?.value;
      if (phone) {
        phone.required = choice === 'phone' || choice === 'whatsapp';
        phone.setAttribute('aria-required', String(phone.required));
      }
      if (email) {
        email.required = choice === 'email';
        email.setAttribute('aria-required', String(email.required));
      }
    };

    form.querySelectorAll('input[name="contact"]').forEach(input => input.addEventListener('change', syncContactRequirements));
    syncContactRequirements();

    form.addEventListener('submit', async event => {
      event.preventDefault();
      syncContactRequirements();
      if (!form.reportValidity()) return;

      const button = form.querySelector('button[type="submit"]');
      const previous = button?.textContent;
      if (button) {
        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        button.textContent = window.PolarisSite?.messages?.sending || 'Sending…';
      }
      if (status) {
        status.hidden = true;
        status.classList.remove('is-error');
        status.textContent = '';
      }

      try {
        const response = await fetch(window.PolarisSite?.ajaxUrl || form.action, {
          method: 'POST',
          body: new FormData(form),
          credentials: 'same-origin',
          headers: { 'X-Requested-With': 'XMLHttpRequest' },
        });
        const payload = await response.json();
        if (!response.ok || !payload.success) {
          throw new Error(payload?.data?.message || window.PolarisSite?.messages?.error || 'Request failed');
        }
        form.reset();
        syncContactRequirements();
        if (status) {
          status.hidden = false;
          status.textContent = payload?.data?.message || window.PolarisSite?.messages?.success;
          status.focus();
        }
      } catch (error) {
        if (status) {
          status.hidden = false;
          status.classList.add('is-error');
          status.textContent = error?.message || window.PolarisSite?.messages?.error || 'Your message could not be sent.';
          status.focus();
        }
      } finally {
        if (button) {
          button.disabled = false;
          button.removeAttribute('aria-busy');
          button.textContent = previous;
        }
      }
    });
  }

  document.querySelectorAll('[data-year]').forEach(node => {
    node.textContent = new Date().getFullYear();
  });
})();
