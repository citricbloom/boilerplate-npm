<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'POLARIS_THEME_VERSION', '1.0.1' );

define( 'POLARIS_THEME_DIR', get_template_directory() );
define( 'POLARIS_THEME_URI', get_template_directory_uri() );

function polaris_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo', [ 'height' => 100, 'width' => 285, 'flex-height' => true, 'flex-width' => true ] );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ] );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'editor-styles' );
    add_editor_style( 'assets/css/editor.css' );
    register_nav_menus( [ 'primary' => __( 'Primary Navigation', 'polaris-wellbeing' ), 'footer' => __( 'Footer Navigation', 'polaris-wellbeing' ) ] );
}
add_action( 'after_setup_theme', 'polaris_theme_setup' );

function polaris_enqueue_assets() {
    $site = POLARIS_THEME_DIR . '/assets/css/styles.css';
    $js   = POLARIS_THEME_DIR . '/assets/js/site.js';
    wp_enqueue_style( 'polaris-site', POLARIS_THEME_URI . '/assets/css/styles.css', [], filemtime( $site ) );
    wp_enqueue_script( 'polaris-site', POLARIS_THEME_URI . '/assets/js/site.js', [], filemtime( $js ), true );
    wp_localize_script( 'polaris-site', 'PolarisSite', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'polaris_enquiry' ),
        'messages' => [
            'sending' => __( 'Sending…', 'polaris-wellbeing' ),
            'success' => __( 'Thank you. Your message has been sent to the Polaris team.', 'polaris-wellbeing' ),
            'error'   => __( 'Your message could not be sent. Please try WhatsApp, call us, or try again shortly.', 'polaris-wellbeing' ),
        ],
    ] );
}
add_action( 'wp_enqueue_scripts', 'polaris_enqueue_assets' );


/**
 * Keep the controlled front end free from WordPress presentation layers that
 * are not used by this theme and could introduce visual drift.
 */
function polaris_remove_unused_frontend_assets() {
    wp_dequeue_style( 'global-styles' );
    wp_dequeue_style( 'classic-theme-styles' );
    wp_dequeue_style( 'wp-block-library' );
    wp_dequeue_style( 'wp-block-library-theme' );
}
add_action( 'wp_enqueue_scripts', 'polaris_remove_unused_frontend_assets', 100 );

function polaris_frontend_hygiene() {
    remove_action( 'wp_head', 'wp_generator' );
    remove_action( 'wp_head', 'rsd_link' );
    remove_action( 'wp_head', 'wlwmanifest_link' );
    remove_action( 'wp_head', 'wp_shortlink_wp_head' );
    remove_action( 'wp_head', 'rest_output_link_wp_head' );
    remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
}
add_action( 'init', 'polaris_frontend_hygiene' );

function polaris_resource_hints( $urls, $relation_type ) {
    if ( 'preconnect' === $relation_type ) {
        return $urls;
    }
    return $urls;
}
add_filter( 'wp_resource_hints', 'polaris_resource_hints', 10, 2 );

function polaris_preload_home_hero() {
    if ( ! is_front_page() ) { return; }
    $mobile  = polaris_image_url( 'home_hero_mobile_image', 'hero-mobile.webp' );
    $desktop = polaris_image_url( 'home_hero_desktop_image', 'hero-desktop.webp' );
    echo '<link rel="preload" as="image" href="' . esc_url( $mobile ) . '" media="(max-width: 759px)" fetchpriority="high">' . "\n";
    echo '<link rel="preload" as="image" href="' . esc_url( $desktop ) . '" media="(min-width: 760px)" fetchpriority="high">' . "\n";
}
add_action( 'wp_head', 'polaris_preload_home_hero', 2 );


function polaris_meta_description() {
    $map = [
        'home' => 'home_hero_lead',
        'how-we-can-help' => 'help_hero_lead',
        'braingym' => 'bg_hero_lead',
        'our-approach' => 'approach_hero_lead',
        'our-team' => 'team_hero_lead',
        'about-polaris' => 'about_hero_lead',
        'talk-to-our-team' => 'contact_hero_lead',
    ];
    $slug = polaris_controlled_slug();
    if ( isset( $map[ $slug ] ) ) {
        echo '<meta name="description" content="' . esc_attr( wp_strip_all_tags( polaris_value( $map[ $slug ] ) ) ) . '">' . "\n";
    }
    echo '<meta name="theme-color" content="#f7f2e9">' . "\n";
    if ( ! has_site_icon() ) {
        echo '<link rel="icon" href="' . esc_url( POLARIS_THEME_URI . '/assets/images/favicon.png' ) . '" type="image/png">' . "\n";
    }
}
add_action( 'wp_head', 'polaris_meta_description', 1 );

// Public parity is evaluated without the WordPress toolbar shifting the page.
add_filter( 'show_admin_bar', '__return_false' );

function polaris_defaults() {
    static $defaults = null;
    if ( null === $defaults ) { $defaults = require POLARIS_THEME_DIR . '/inc/defaults.php'; }
    return $defaults;
}

function polaris_value( $key ) {
    $defaults = polaris_defaults();
    if ( function_exists( 'polaris_core_get_value' ) ) {
        return polaris_core_get_value( $key, $defaults[ $key ] ?? '' );
    }
    return $defaults[ $key ] ?? '';
}

function polaris_page_id_by_slug( $slug ) {
    $page = get_page_by_path( $slug );
    return $page ? (int) $page->ID : 0;
}

function polaris_page_url( $slug ) {
    if ( 'home' === $slug ) { return home_url( '/' ); }
    $id = polaris_page_id_by_slug( $slug );
    return $id ? get_permalink( $id ) : home_url( '/' . trim( $slug, '/' ) . '/' );
}

function polaris_image_url( $option_key, $fallback ) {
    $id = absint( polaris_value( $option_key ) );
    if ( $id ) {
        $url = wp_get_attachment_image_url( $id, 'full' );
        if ( $url ) { return $url; }
    }
    return POLARIS_THEME_URI . '/assets/images/' . ltrim( $fallback, '/' );
}

function polaris_logo_url() {
    $custom_logo_id = get_theme_mod( 'custom_logo' );
    if ( $custom_logo_id ) {
        $url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
        if ( $url ) { return $url; }
    }
    return POLARIS_THEME_URI . '/assets/images/polaris-mark.png';
}

function polaris_menu_items_default() {
    return [
        [ 'slug' => 'how-we-can-help', 'label' => 'How We Can Help', 'class' => '' ],
        [ 'slug' => 'braingym', 'label' => 'BrainGym', 'class' => 'nav-braingym' ],
        [ 'slug' => 'our-approach', 'label' => 'Our Approach', 'class' => '' ],
        [ 'slug' => 'our-team', 'label' => 'Our Team', 'class' => '' ],
        [ 'slug' => 'about-polaris', 'label' => 'About Polaris', 'class' => '' ],
    ];
}

function polaris_render_menu( $location = 'primary' ) {
    $locations = get_nav_menu_locations();
    $items = [];
    if ( isset( $locations[ $location ] ) ) {
        $raw = wp_get_nav_menu_items( $locations[ $location ] );
        if ( is_array( $raw ) ) {
            foreach ( $raw as $item ) {
                if ( (int) $item->menu_item_parent !== 0 ) { continue; }
                $class = in_array( 'nav-braingym', (array) $item->classes, true ) || stripos( $item->title, 'BrainGym' ) !== false ? 'nav-braingym' : '';
                $items[] = [ 'url' => $item->url, 'label' => $item->title, 'class' => $class ];
            }
        }
    }
    if ( ! $items ) {
        foreach ( polaris_menu_items_default() as $item ) {
            $items[] = [ 'url' => polaris_page_url( $item['slug'] ), 'label' => $item['label'], 'class' => $item['class'] ];
        }
        if ( 'footer' === $location ) {
            $items[] = [ 'url' => polaris_page_url( 'talk-to-our-team' ), 'label' => 'Talk to our team', 'class' => '' ];
        }
    }
    $html = '';
    foreach ( $items as $item ) {
        $class = $item['class'] ? ' class="' . esc_attr( $item['class'] ) . '"' : '';
        $html .= '<a href="' . esc_url( $item['url'] ) . '"' . $class . '>' . esc_html( $item['label'] ) . '</a>';
    }
    return $html;
}

function polaris_team_posts() {
    $posts = get_posts( [ 'post_type' => 'polaris_team', 'post_status' => 'publish', 'posts_per_page' => 50, 'orderby' => [ 'menu_order' => 'ASC', 'title' => 'ASC' ] ] );
    return $posts ?: [];
}

function polaris_team_image( $post, $fallback_key = '' ) {
    if ( $post && has_post_thumbnail( $post ) ) {
        $url = get_the_post_thumbnail_url( $post, 'full' );
        if ( $url ) { return $url; }
    }
    if ( ! $fallback_key && $post ) {
        $fallback_key = get_post_meta( $post->ID, '_polaris_fallback_image', true );
    }
    if ( $fallback_key && in_array( $fallback_key, [ 'cher', 'laura', 'stephanie', 'karen' ], true ) ) {
        return POLARIS_THEME_URI . '/assets/images/' . $fallback_key . '.webp';
    }
    return POLARIS_THEME_URI . '/assets/images/cher.webp';
}

function polaris_render_home_offer_rows() {
    $posts = get_posts( [ 'post_type' => 'polaris_service', 'post_status' => 'publish', 'posts_per_page' => 4, 'meta_key' => '_polaris_featured_home', 'meta_value' => '1', 'orderby' => [ 'menu_order' => 'ASC', 'date' => 'ASC' ] ] );
    if ( ! $posts ) { return ''; }
    $html = '';
    foreach ( $posts as $post ) {
        $target = get_post_meta( $post->ID, '_polaris_target', true );
        $href = $target ? polaris_page_url( $target ) : polaris_page_url( 'how-we-can-help' );
        $anchor = get_post_meta( $post->ID, '_polaris_anchor', true );
        if ( $anchor ) { $href .= '#' . rawurlencode( $anchor ); }
        $sub = get_post_meta( $post->ID, '_polaris_home_subtitle', true );
        $summary = get_post_meta( $post->ID, '_polaris_home_summary', true );
        $html .= '<a class="offer-row" href="' . esc_url( $href ) . '"><div><h3>' . esc_html( get_the_title( $post ) ) . '</h3><p>' . esc_html( $sub ) . '</p></div><p>' . esc_html( $summary ) . '</p><span class="offer-arrow" aria-hidden="true">↗</span></a>';
    }
    return $html;
}

function polaris_render_service_accordion() {
    $posts = get_posts( [ 'post_type' => 'polaris_service', 'post_status' => 'publish', 'posts_per_page' => 50, 'orderby' => [ 'menu_order' => 'ASC', 'date' => 'ASC' ] ] );
    $html = '';
    foreach ( $posts as $index => $post ) {
        $anchor = get_post_meta( $post->ID, '_polaris_anchor', true );
        $open = 0 === $index ? ' open' : '';
        $id = $anchor ? ' id="' . esc_attr( $anchor ) . '"' : '';
        $html .= '<details' . $id . $open . '><summary>' . esc_html( get_the_title( $post ) ) . '</summary><div class="details-body">';
        $html .= wp_kses_post( apply_filters( 'the_content', $post->post_content ) );
        $target = get_post_meta( $post->ID, '_polaris_target', true );
        if ( 'braingym' === $target ) { $html .= '<p><a href="' . esc_url( polaris_page_url( 'braingym' ) ) . '">Explore BrainGym ↗</a></p>'; }
        $html .= '</div></details>';
    }
    return $html;
}

function polaris_render_team_grid() {
    $html = '';
    foreach ( polaris_team_posts() as $post ) {
        $role = get_post_meta( $post->ID, '_polaris_role', true );
        $html .= '<article class="team-card"><div class="team-photo"><img loading="lazy" decoding="async" src="' . esc_url( polaris_team_image( $post ) ) . '" alt="' . esc_attr( get_the_title( $post ) ) . '"></div><h3>' . esc_html( get_the_title( $post ) ) . '</h3><p>' . esc_html( $role ) . '</p></article>';
    }
    return $html;
}

function polaris_render_people_strip() {
    $posts = array_slice( polaris_team_posts(), 0, 4 );
    $html = '';
    foreach ( $posts as $post ) { $html .= '<img loading="lazy" decoding="async" src="' . esc_url( polaris_team_image( $post ) ) . '" alt="' . esc_attr( get_the_title( $post ) ) . '">'; }
    $html .= '<span>' . esc_html( polaris_value( 'home_people_label' ) ) . '</span>';
    return $html;
}

function polaris_render_trust_list() {
    $html = '';
    for ( $i = 1; $i <= 4; $i++ ) {
        $html .= '<li><strong>' . esc_html( polaris_value( 'home_trust_' . $i . '_title' ) ) . '</strong><span>' . esc_html( polaris_value( 'home_trust_' . $i . '_text' ) ) . '</span></li>';
    }
    return $html;
}

function polaris_capture_action( $action ) {
    ob_start(); do_action( $action ); return ob_get_clean();
}

function polaris_render_controlled_page( $slug ) {
    $path = POLARIS_THEME_DIR . '/static/' . sanitize_file_name( $slug ) . '.html';
    if ( ! is_readable( $path ) ) { return false; }
    $html = file_get_contents( $path );

    $classes = implode( ' ', array_map( 'sanitize_html_class', get_body_class() ) );

    // Resolve dynamic content first. Content filters may enqueue assets that
    // must be available when wp_head() and wp_footer() are captured.
    $replacements = [
        '{{language_attributes}}' => get_language_attributes(),
        '{{body_classes}}' => esc_attr( $classes ),
        '{{document_title}}' => esc_html( wp_get_document_title() ),
        '{{logo_url}}' => esc_url( polaris_logo_url() ),
        '{{desktop_nav}}' => polaris_render_menu( 'primary' ),
        '{{mobile_nav}}' => polaris_render_menu( 'primary' ),
        '{{footer_nav}}' => polaris_render_menu( 'footer' ),
        '{{home_offer_rows}}' => polaris_render_home_offer_rows(),
        '{{service_accordion}}' => polaris_render_service_accordion(),
        '{{team_grid}}' => polaris_render_team_grid(),
        '{{home_people_strip}}' => polaris_render_people_strip(),
        '{{home_trust_list}}' => polaris_render_trust_list(),
        '{{home_hero_mobile_url}}' => esc_url( polaris_image_url( 'home_hero_mobile_image', 'hero-mobile.webp' ) ),
        '{{home_hero_desktop_url}}' => esc_url( polaris_image_url( 'home_hero_desktop_image', 'hero-desktop.webp' ) ),
        '{{home_lower_url}}' => esc_url( polaris_image_url( 'home_lower_image', 'polaris-space.webp' ) ),
        '{{bg_hero_url}}' => esc_url( polaris_image_url( 'bg_hero_image', 'braingym-cap.webp' ) ),
        '{{approach_image_url}}' => esc_url( polaris_image_url( 'approach_image', 'polaris-space.webp' ) ),
        '{{about_image_url}}' => esc_url( polaris_image_url( 'about_image', 'polaris-space.webp' ) ),
        '{{team_image_cher}}' => esc_url( POLARIS_THEME_URI . '/assets/images/cher.webp' ),
        '{{team_image_laura}}' => esc_url( POLARIS_THEME_URI . '/assets/images/laura.webp' ),
        '{{team_image_stephanie}}' => esc_url( POLARIS_THEME_URI . '/assets/images/stephanie.webp' ),
        '{{team_image_karen}}' => esc_url( POLARIS_THEME_URI . '/assets/images/karen.webp' ),
        '{{whatsapp_url}}' => esc_url( 'https://wa.me/' . preg_replace( '/\D+/', '', polaris_value( 'global_whatsapp_href' ) ) ),
        '{{phone_url}}' => esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', polaris_value( 'global_phone_href' ) ) ),
        '{{ajax_url}}' => esc_url( admin_url( 'admin-ajax.php' ) ),
        '{{global_footer_meta}}' => esc_html( polaris_value( 'global_footer_meta' ) ),
        '{{year}}' => esc_html( gmdate( 'Y' ) ),
        '{{privacy_url}}' => esc_url( get_privacy_policy_url() ?: home_url( '/privacy-policy/' ) ),
        '{{form_hidden_fields}}' => '<input type="hidden" name="action" value="polaris_submit_enquiry"><input type="hidden" name="nonce" value="' . esc_attr( wp_create_nonce( 'polaris_enquiry' ) ) . '"><input class="polaris-honeypot" type="text" name="website" value="" tabindex="-1" autocomplete="off" aria-hidden="true">',
    ];

    foreach ( [ 'home','how-we-can-help','braingym','our-approach','our-team','about-polaris','talk-to-our-team' ] as $page_slug ) {
        $replacements[ '{{url_' . $page_slug . '}}' ] = esc_url( polaris_page_url( $page_slug ) );
    }
    foreach ( polaris_defaults() as $key => $default ) {
        $replacements[ '{{' . $key . '}}' ] = esc_html( polaris_value( $key ) );
    }

    // Execute WordPress lifecycle hooks in their normal order even though the
    // controlled document is assembled as a single rendered string.
    $replacements['{{wp_head}}'] = polaris_capture_action( 'wp_head' );
    $replacements['{{wp_body_open}}'] = polaris_capture_action( 'wp_body_open' );
    $replacements['{{wp_footer}}'] = polaris_capture_action( 'wp_footer' );

    $html = strtr( $html, $replacements );
    // Unknown tokens fail low rather than exposing implementation internals.
    $html = preg_replace( '/\{\{[a-zA-Z0-9_-]+\}\}/', '', $html );
    echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- substitutions are escaped above.
    return true;
}

function polaris_controlled_slug() {
    if ( is_front_page() ) { return 'home'; }
    if ( is_page() ) {
        $slug = get_post_field( 'post_name', get_queried_object_id() );
        $allowed = [ 'how-we-can-help','braingym','our-approach','our-team','about-polaris','talk-to-our-team' ];
        if ( in_array( $slug, $allowed, true ) ) { return $slug; }
    }
    return '';
}
