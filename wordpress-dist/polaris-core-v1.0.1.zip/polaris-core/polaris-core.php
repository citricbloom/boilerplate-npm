<?php
/**
 * Plugin Name: Polaris Core
 * Description: Structured content, settings, team/services and enquiry handling for the Polaris Wellbeing theme.
 * Version: 1.0.1
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Author: Polaris Wellbeing
 * Text Domain: polaris-core
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'POLARIS_CORE_VERSION', '1.0.1' );
define( 'POLARIS_CORE_DIR', plugin_dir_path( __FILE__ ) );

function polaris_core_defaults() {
    static $defaults = null;
    if ( null === $defaults ) { $defaults = require POLARIS_CORE_DIR . 'defaults.php'; }
    return $defaults;
}
function polaris_core_schema() {
    static $schema = null;
    if ( null === $schema ) { $schema = require POLARIS_CORE_DIR . 'field-schema.php'; }
    return $schema;
}
function polaris_core_get_value( $key, $fallback = '' ) {
    $values = get_option( 'polaris_content', [] );
    return isset( $values[ $key ] ) && '' !== $values[ $key ] ? $values[ $key ] : $fallback;
}

function polaris_core_register_post_types() {
    register_post_type( 'polaris_service', [
        'labels' => [ 'name' => 'Services', 'singular_name' => 'Service', 'add_new_item' => 'Add Service', 'edit_item' => 'Edit Service' ],
        'public' => false, 'show_ui' => true, 'show_in_rest' => true, 'menu_icon' => 'dashicons-heart',
        'supports' => [ 'title', 'editor', 'excerpt', 'page-attributes' ],
        'capability_type' => 'page', 'map_meta_cap' => true,
    ] );
    register_post_type( 'polaris_team', [
        'labels' => [ 'name' => 'Team', 'singular_name' => 'Team Member', 'add_new_item' => 'Add Team Member', 'edit_item' => 'Edit Team Member' ],
        'public' => false, 'show_ui' => true, 'show_in_rest' => true, 'menu_icon' => 'dashicons-groups',
        'supports' => [ 'title', 'editor', 'thumbnail', 'page-attributes' ],
        'capability_type' => 'page', 'map_meta_cap' => true,
    ] );
    register_post_type( 'polaris_testimonial', [
        'labels' => [ 'name' => 'Testimonials', 'singular_name' => 'Testimonial' ],
        'public' => false, 'show_ui' => true, 'show_in_rest' => true, 'menu_icon' => 'dashicons-format-quote',
        'supports' => [ 'title', 'editor', 'page-attributes' ],
    ] );
    register_post_type( 'polaris_programme', [
        'labels' => [ 'name' => 'Programmes', 'singular_name' => 'Programme' ],
        'public' => true, 'show_ui' => true, 'show_in_rest' => true, 'menu_icon' => 'dashicons-calendar-alt',
        'supports' => [ 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ],
        'rewrite' => [ 'slug' => 'programmes' ],
    ] );
}
add_action( 'init', 'polaris_core_register_post_types' );

function polaris_core_add_meta_boxes() {
    add_meta_box( 'polaris_service_details', 'Service display settings', 'polaris_core_service_box', 'polaris_service', 'normal', 'high' );
    add_meta_box( 'polaris_team_details', 'Team member details', 'polaris_core_team_box', 'polaris_team', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'polaris_core_add_meta_boxes' );

function polaris_core_service_box( $post ) {
    wp_nonce_field( 'polaris_service_meta', 'polaris_service_nonce' );
    $fields = [
        '_polaris_anchor' => [ 'Section anchor', 'text' ], '_polaris_target' => [ 'Destination page slug', 'text' ],
        '_polaris_home_subtitle' => [ 'Homepage subtitle', 'text' ], '_polaris_home_summary' => [ 'Homepage summary', 'textarea' ],
        '_polaris_featured_home' => [ 'Show on homepage', 'checkbox' ],
    ];
    echo '<table class="form-table"><tbody>';
    foreach ( $fields as $key => $config ) {
        $value = get_post_meta( $post->ID, $key, true );
        echo '<tr><th><label for="' . esc_attr( $key ) . '">' . esc_html( $config[0] ) . '</label></th><td>';
        if ( 'textarea' === $config[1] ) echo '<textarea class="large-text" rows="3" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( $value ) . '</textarea>';
        elseif ( 'checkbox' === $config[1] ) echo '<label><input type="checkbox" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="1" ' . checked( $value, '1', false ) . '> Yes</label>';
        else echo '<input class="regular-text" type="text" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
        echo '</td></tr>';
    }
    echo '</tbody></table>';
}
function polaris_core_team_box( $post ) {
    wp_nonce_field( 'polaris_team_meta', 'polaris_team_nonce' );
    $role = get_post_meta( $post->ID, '_polaris_role', true );
    $qual = get_post_meta( $post->ID, '_polaris_qualifications', true );
    $languages = get_post_meta( $post->ID, '_polaris_languages', true );
    echo '<table class="form-table"><tbody><tr><th><label for="_polaris_role">Role / professional title</label></th><td><input class="large-text" type="text" id="_polaris_role" name="_polaris_role" value="' . esc_attr( $role ) . '"></td></tr><tr><th><label for="_polaris_qualifications">Qualifications / registrations</label></th><td><textarea class="large-text" rows="4" id="_polaris_qualifications" name="_polaris_qualifications">' . esc_textarea( $qual ) . '</textarea></td></tr><tr><th><label for="_polaris_languages">Languages</label></th><td><input class="large-text" type="text" id="_polaris_languages" name="_polaris_languages" value="' . esc_attr( $languages ) . '"></td></tr></tbody></table>';
}
function polaris_core_save_meta( $post_id, $post ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( 'polaris_service' === $post->post_type && isset( $_POST['polaris_service_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['polaris_service_nonce'] ) ), 'polaris_service_meta' ) && current_user_can( 'edit_post', $post_id ) ) {
        foreach ( [ '_polaris_anchor','_polaris_target','_polaris_home_subtitle' ] as $key ) update_post_meta( $post_id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) ) );
        update_post_meta( $post_id, '_polaris_home_summary', sanitize_textarea_field( wp_unslash( $_POST['_polaris_home_summary'] ?? '' ) ) );
        update_post_meta( $post_id, '_polaris_featured_home', isset( $_POST['_polaris_featured_home'] ) ? '1' : '0' );
    }
    if ( 'polaris_team' === $post->post_type && isset( $_POST['polaris_team_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['polaris_team_nonce'] ) ), 'polaris_team_meta' ) && current_user_can( 'edit_post', $post_id ) ) {
        update_post_meta( $post_id, '_polaris_role', sanitize_text_field( wp_unslash( $_POST['_polaris_role'] ?? '' ) ) );
        update_post_meta( $post_id, '_polaris_qualifications', sanitize_textarea_field( wp_unslash( $_POST['_polaris_qualifications'] ?? '' ) ) );
        update_post_meta( $post_id, '_polaris_languages', sanitize_text_field( wp_unslash( $_POST['_polaris_languages'] ?? '' ) ) );
    }
}
add_action( 'save_post', 'polaris_core_save_meta', 10, 2 );

function polaris_core_admin_menu() {
    add_menu_page( 'Polaris Site Content', 'Polaris Content', 'manage_options', 'polaris-content', 'polaris_core_settings_page', 'dashicons-edit-page', 3 );
}
add_action( 'admin_menu', 'polaris_core_admin_menu' );

function polaris_core_admin_assets( $hook ) {
    if ( 'toplevel_page_polaris-content' !== $hook ) return;
    wp_enqueue_media();
    wp_enqueue_style( 'polaris-admin', plugin_dir_url( __FILE__ ) . 'admin.css', [], POLARIS_CORE_VERSION );
    wp_enqueue_script( 'polaris-admin', plugin_dir_url( __FILE__ ) . 'admin.js', [ 'jquery' ], POLARIS_CORE_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'polaris_core_admin_assets' );

function polaris_core_sanitize_content( $input ) {
    $clean = wp_parse_args( get_option( 'polaris_content', [] ), polaris_core_defaults() );
    foreach ( polaris_core_schema() as $tab => $fields ) {
        foreach ( $fields as $field ) {
            [ $key, $label, $type ] = $field;
            if ( ! array_key_exists( $key, (array) $input ) ) { continue; }
            $value = $input[ $key ];
            if ( 'media' === $type ) $clean[ $key ] = absint( $value );
            elseif ( 'email' === $type ) $clean[ $key ] = sanitize_email( $value );
            elseif ( 'url' === $type ) $clean[ $key ] = esc_url_raw( $value );
            elseif ( 'textarea' === $type ) $clean[ $key ] = sanitize_textarea_field( $value );
            else $clean[ $key ] = sanitize_text_field( $value );
        }
    }
    return $clean;
}
function polaris_core_register_settings() {
    register_setting( 'polaris_content_group', 'polaris_content', [ 'sanitize_callback' => 'polaris_core_sanitize_content', 'default' => polaris_core_defaults() ] );
}
add_action( 'admin_init', 'polaris_core_register_settings' );

function polaris_core_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $schema = polaris_core_schema();
    $values = wp_parse_args( get_option( 'polaris_content', [] ), polaris_core_defaults() );
    $active = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'home';
    if ( ! isset( $schema[ $active ] ) ) $active = 'home';
    echo '<div class="wrap polaris-admin"><h1>Polaris Site Content</h1><p class="description">Edit operational content without changing the approved layout, typography or mobile behaviour.</p><nav class="nav-tab-wrapper">';
    $labels = [ 'home'=>'Home','how-we-can-help'=>'How We Can Help','braingym'=>'BrainGym','our-approach'=>'Our Approach','our-team'=>'Our Team','about-polaris'=>'About','talk-to-our-team'=>'Contact','global'=>'Global' ];
    foreach ( $schema as $tab => $_ ) echo '<a class="nav-tab ' . ( $active === $tab ? 'nav-tab-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=polaris-content&tab=' . $tab ) ) . '">' . esc_html( $labels[ $tab ] ?? ucwords( str_replace( '-', ' ', $tab ) ) ) . '</a>';
    echo '</nav><form method="post" action="options.php">';
    settings_fields( 'polaris_content_group' );
    echo '<div class="polaris-field-grid">';
    foreach ( $schema[ $active ] as $field ) {
        [ $key, $label, $type, $default ] = $field;
        $value = $values[ $key ] ?? $default;
        echo '<div class="polaris-field"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label>';
        if ( 'textarea' === $type ) echo '<textarea id="' . esc_attr( $key ) . '" name="polaris_content[' . esc_attr( $key ) . ']" rows="4">' . esc_textarea( $value ) . '</textarea>';
        elseif ( 'media' === $type ) { $preview = $value ? wp_get_attachment_image_url( $value, 'medium' ) : ''; echo '<div class="polaris-media-field"><input type="hidden" id="' . esc_attr( $key ) . '" name="polaris_content[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '"><div class="polaris-media-preview">' . ( $preview ? '<img src="' . esc_url( $preview ) . '" alt="">' : '<span>Using the approved theme image</span>' ) . '</div><button type="button" class="button polaris-select-media" data-target="' . esc_attr( $key ) . '">Choose image</button><button type="button" class="button-link-delete polaris-clear-media" data-target="' . esc_attr( $key ) . '">Use approved default</button></div>'; }
        else echo '<input type="' . esc_attr( 'email' === $type ? 'email' : ( 'url' === $type ? 'url' : 'text' ) ) . '" id="' . esc_attr( $key ) . '" name="polaris_content[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '">';
        echo '</div>';
    }
    echo '</div>'; submit_button( 'Save Polaris content' ); echo '</form></div>';
}

function polaris_core_seed_page( $title, $slug ) {
    $page = get_page_by_path( $slug );
    if ( $page ) return (int) $page->ID;
    return (int) wp_insert_post( [ 'post_type'=>'page','post_status'=>'publish','post_title'=>$title,'post_name'=>$slug,'post_content'=>'<!-- Managed by Polaris Content. -->' ] );
}
function polaris_core_find_seeded_post( $post_type, $title ) {
    $posts = get_posts( [
        'post_type' => $post_type,
        'post_status' => 'any',
        'posts_per_page' => 1,
        'title' => $title,
        'fields' => 'ids',
        'suppress_filters' => true,
    ] );
    return $posts ? (int) $posts[0] : 0;
}
function polaris_core_seed_service( $data, $order ) {
    if ( polaris_core_find_seeded_post( 'polaris_service', $data['title'] ) ) return;
    $id = wp_insert_post( [ 'post_type'=>'polaris_service','post_status'=>'publish','post_title'=>$data['title'],'post_content'=>$data['content'],'menu_order'=>$order ], true );
    if ( is_wp_error( $id ) ) return;
    foreach ( $data['meta'] as $key=>$value ) update_post_meta( $id, $key, $value );
}
function polaris_core_seed_team( $data, $order ) {
    if ( polaris_core_find_seeded_post( 'polaris_team', $data['name'] ) ) return;
    $id = wp_insert_post( [ 'post_type'=>'polaris_team','post_status'=>'publish','post_title'=>$data['name'],'post_content'=>'','menu_order'=>$order ], true );
    if ( is_wp_error( $id ) ) return;
    update_post_meta( $id, '_polaris_role', $data['role'] );
    update_post_meta( $id, '_polaris_fallback_image', $data['image'] ?? '' );
}
function polaris_core_activate() {
    polaris_core_register_post_types();
    if ( ! get_option( 'polaris_content' ) ) update_option( 'polaris_content', polaris_core_defaults() );
    $pages = [ 'home'=>'Home','how-we-can-help'=>'How We Can Help','braingym'=>'BrainGym','our-approach'=>'Our Approach','our-team'=>'Our Team','about-polaris'=>'About Polaris','talk-to-our-team'=>'Talk to our team','privacy-policy'=>'Privacy Policy' ];
    $ids=[]; foreach ( $pages as $slug=>$title ) $ids[$slug]=polaris_core_seed_page($title,$slug);
    $privacy = get_post( $ids['privacy-policy'] );
    if ( $privacy && trim( wp_strip_all_tags( $privacy->post_content ) ) === '' ) {
        wp_update_post( [
            'ID' => $privacy->ID,
            'post_content' => '<h2>Website enquiries</h2><p>When you contact Polaris through this website, the details you provide are used to respond to your enquiry. Please do not use the form for emergencies or include highly sensitive clinical information.</p><h2>Cookies and technical data</h2><p>The website may process essential technical information required for security, reliability and correct operation. Any analytics or optional cookies should be documented here before they are enabled.</p><h2>Your rights and contact</h2><p>Contact Polaris Wellbeing at info@polariswellbeing.com with privacy questions or requests relating to your personal data. This policy must be reviewed and approved by Polaris before the site is made publicly searchable.</p>',
        ] );
    }
    update_option( 'show_on_front', 'page' ); update_option( 'page_on_front', $ids['home'] ); update_option( 'wp_page_for_privacy_policy', $ids['privacy-policy'] );
    if ( ! get_option( 'permalink_structure' ) ) update_option( 'permalink_structure', '/%postname%/' );

    $services = [
      [ 'title'=>'Therapy & emotional wellbeing','content'=>'<p>Individual therapy, psychotherapy, counselling and support for anxiety, stress, mood, trauma, loss, identity, life changes and emotional wellbeing.</p><ul><li>Individual psychology and therapy</li><li>Psychotherapy and counselling</li><li>EMDR and trauma-informed support</li><li>Mindfulness-based approaches</li></ul>','meta'=>['_polaris_anchor'=>'therapy','_polaris_target'=>'how-we-can-help','_polaris_home_subtitle'=>'Individual, couples and family support.','_polaris_home_summary'=>'Space to understand, reflect and move forward.','_polaris_featured_home'=>'1'] ],
      [ 'title'=>'Relationships, couples & families','content'=>'<p>Support with relationships, communication, parenting, separation, family dynamics and times of change.</p><ul><li>Couples and relationship therapy</li><li>Family therapy</li><li>Parent guidance and support</li></ul>','meta'=>['_polaris_anchor'=>'relationships','_polaris_target'=>'how-we-can-help','_polaris_featured_home'=>'0'] ],
      [ 'title'=>'Children & young people','content'=>'<p>Psychological, developmental and therapeutic support shaped around the child or young person, with family involvement where useful.</p><ul><li>Emotional and behavioural support</li><li>Developmental and neurodiversity support</li><li>Speech and occupational support</li><li>Parent and family work</li></ul>','meta'=>['_polaris_anchor'=>'young-people','_polaris_target'=>'how-we-can-help','_polaris_home_subtitle'=>'Support shaped around age, development and family life.','_polaris_home_summary'=>'For emotional, behavioural, relational and developmental needs.','_polaris_featured_home'=>'1'] ],
      [ 'title'=>'Assessment & specialist support','content'=>'<p>Assessment can help build a clearer picture and guide useful next steps. Available services include psychological, psychometric, developmental, psychiatric and other specialist input.</p><ul><li>ADHD, autism and neurodiversity</li><li>Psychological and psychometric assessment</li><li>Psychiatry and medical support</li><li>Occupational and speech-language assessment</li></ul>','meta'=>['_polaris_anchor'=>'assessment','_polaris_target'=>'how-we-can-help','_polaris_home_subtitle'=>'Clearer understanding from the right professional.','_polaris_home_summary'=>'Psychological, developmental, psychiatric and wider specialist input.','_polaris_featured_home'=>'1'] ],
      [ 'title'=>'Coaching, confidence & performance','content'=>'<p>Goal-focused support for personal development, career decisions, executive performance, confidence, neurodivergence and life transitions.</p>','meta'=>['_polaris_anchor'=>'coaching','_polaris_target'=>'how-we-can-help','_polaris_featured_home'=>'0'] ],
      [ 'title'=>'Body & physical wellbeing','content'=>'<p>Physical, lifestyle and complementary wellbeing services can sit alongside the wider Polaris offering when they are relevant to the person.</p>','meta'=>['_polaris_anchor'=>'body','_polaris_target'=>'how-we-can-help','_polaris_featured_home'=>'0'] ],
      [ 'title'=>'BrainGym','content'=>'<p>qEEG brain mapping and EEG-based neurofeedback provide an additional specialist perspective within Polaris.</p>','meta'=>['_polaris_anchor'=>'braingym','_polaris_target'=>'braingym','_polaris_home_subtitle'=>'qEEG brain mapping and neurofeedback.','_polaris_home_summary'=>'A distinctive additional perspective within the wider Polaris team.','_polaris_featured_home'=>'1'] ],
    ];
    foreach ( $services as $i=>$service ) polaris_core_seed_service($service,$i);
    $team=[
      ['name'=>'Cher Engerer Kerr','role'=>'Founder, CEO & Clinical Director','image'=>'cher'],
      ['name'=>'Laura Sue Armeni','role'=>'Managing Partner, Psychologist & Psychotherapist','image'=>'laura'],
      ['name'=>'Stephanie Xuereb','role'=>'Counsellor, Psychotherapist & CBT Practitioner','image'=>'stephanie'],
      ['name'=>'Karen Theuma','role'=>'Gestalt Psychotherapist & Holistic Practitioner','image'=>'karen'],
    ];
    foreach($team as $i=>$member) polaris_core_seed_team($member,$i);

    $menu_name = 'Polaris Primary';
    $menu = wp_get_nav_menu_object( $menu_name );
    $menu_id = $menu ? (int) $menu->term_id : wp_create_nav_menu( $menu_name );
    if ( $menu_id && ! is_wp_error( $menu_id ) && ! wp_get_nav_menu_items( $menu_id ) ) {
        $menu_pages = [ 'how-we-can-help'=>'How We Can Help','braingym'=>'BrainGym','our-approach'=>'Our Approach','our-team'=>'Our Team','about-polaris'=>'About Polaris' ];
        foreach ( $menu_pages as $slug => $label ) {
            wp_update_nav_menu_item( $menu_id, 0, [
                'menu-item-title' => $label,
                'menu-item-object' => 'page',
                'menu-item-object-id' => $ids[ $slug ],
                'menu-item-type' => 'post_type',
                'menu-item-status' => 'publish',
                'menu-item-classes' => 'braingym' === $slug ? 'nav-braingym' : '',
            ] );
        }
    }
    $footer_name = 'Polaris Footer';
    $footer = wp_get_nav_menu_object( $footer_name );
    $footer_id = $footer ? (int) $footer->term_id : wp_create_nav_menu( $footer_name );
    if ( $footer_id && ! is_wp_error( $footer_id ) && ! wp_get_nav_menu_items( $footer_id ) ) {
        foreach ( [ 'how-we-can-help','braingym','our-approach','our-team','about-polaris','talk-to-our-team' ] as $slug ) {
            wp_update_nav_menu_item( $footer_id, 0, [
                'menu-item-title' => $pages[ $slug ],
                'menu-item-object' => 'page',
                'menu-item-object-id' => $ids[ $slug ],
                'menu-item-type' => 'post_type',
                'menu-item-status' => 'publish',
                'menu-item-classes' => 'braingym' === $slug ? 'nav-braingym' : '',
            ] );
        }
    }
    $locations = get_theme_mod( 'nav_menu_locations', [] );
    if ( $menu_id && ! is_wp_error( $menu_id ) ) $locations['primary'] = (int) $menu_id;
    if ( $footer_id && ! is_wp_error( $footer_id ) ) $locations['footer'] = (int) $footer_id;
    set_theme_mod( 'nav_menu_locations', $locations );

    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'polaris_core_activate' );


function polaris_core_limit_text( $value, $length ) {
    return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $length ) : substr( $value, 0, $length );
}

function polaris_core_handle_enquiry() {
    check_ajax_referer( 'polaris_enquiry', 'nonce' );
    if ( ! empty( $_POST['website'] ) ) wp_send_json_success( [ 'message' => 'Thank you.' ] );

    $name        = polaris_core_limit_text( sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ), 120 );
    $enquiry_for = sanitize_text_field( wp_unslash( $_POST['enquiry_for'] ?? '' ) );
    $contact     = sanitize_key( wp_unslash( $_POST['contact'] ?? '' ) );
    $phone       = polaris_core_limit_text( sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ), 40 );
    $email       = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
    $message     = polaris_core_limit_text( sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) ), 3000 );
    $consent     = ! empty( $_POST['consent'] );

    $allowed_enquiry_for = [ 'Myself', 'My child or young person', 'My partner or family', 'Someone else', 'An organisation' ];
    if ( ! in_array( $enquiry_for, $allowed_enquiry_for, true ) ) $enquiry_for = 'Not specified';
    if ( ! $consent ) wp_send_json_error( [ 'message'=>'Please confirm the privacy consent.' ], 422 );
    if ( ! $name || ! in_array( $contact, [ 'whatsapp','phone','email' ], true ) ) wp_send_json_error( [ 'message'=>'Please complete the required fields.' ], 422 );
    if ( 'email' === $contact && ! is_email( $email ) ) wp_send_json_error( [ 'message'=>'Please enter a valid email address.' ], 422 );
    if ( in_array( $contact, [ 'phone','whatsapp' ], true ) && ! preg_match( '/^[0-9+() .-]{6,40}$/', $phone ) ) wp_send_json_error( [ 'message'=>'Please enter a valid phone number.' ], 422 );

    $fingerprint = hash( 'sha256', ( $_SERVER['REMOTE_ADDR'] ?? '' ) . '|' . strtolower( $email ) . '|' . $phone );
    if ( get_transient( 'polaris_enquiry_' . $fingerprint ) ) wp_send_json_error( [ 'message'=>'Please wait a moment before sending another message.' ], 429 );
    set_transient( 'polaris_enquiry_' . $fingerprint, 1, MINUTE_IN_SECONDS );

    $recipient = polaris_core_get_value( 'global_form_recipient', get_option( 'admin_email' ) );
    if ( ! is_email( $recipient ) ) $recipient = get_option( 'admin_email' );
    $subject = 'New Polaris website enquiry from ' . $name;
    $body = "Name: $name\nEnquiry for: $enquiry_for\nPreferred contact: $contact\nPhone: $phone\nEmail: $email\n\nMessage:\n$message";
    $headers = [ 'Content-Type: text/plain; charset=UTF-8', 'X-Auto-Response-Suppress: All' ];
    if ( is_email( $email ) ) $headers[] = 'Reply-To: ' . $name . ' <' . $email . '>';

    $local = in_array( wp_get_environment_type(), [ 'local','development' ], true ) || defined( 'POLARIS_QA_MODE' );
    $sent = $local ? true : wp_mail( $recipient, $subject, $body, $headers );
    if ( ! $sent ) wp_send_json_error( [ 'message'=>'The message could not be delivered. Please try WhatsApp or call us.' ], 500 );
    wp_send_json_success( [ 'message'=>'Thank you. Your message has been sent to the Polaris team.' ] );
}
add_action( 'wp_ajax_nopriv_polaris_submit_enquiry', 'polaris_core_handle_enquiry' );
add_action( 'wp_ajax_polaris_submit_enquiry', 'polaris_core_handle_enquiry' );


function polaris_core_after_switch_theme() {
    if ( 'polaris-wellbeing' === get_stylesheet() ) {
        polaris_core_activate();
    }
}
add_action( 'after_switch_theme', 'polaris_core_after_switch_theme' );
