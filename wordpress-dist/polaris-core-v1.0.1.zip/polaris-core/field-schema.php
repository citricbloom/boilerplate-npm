<?php
return [
    'global' => [
        [
            'global_footer_blurb',
            'Footer description',
            'textarea',
            'Therapy, BrainGym, assessment and specialist support in one welcoming place.'
        ],
        [
            'global_footer_meta',
            'Footer legal line',
            'text',
            'Polaris Wellbeing · Malta'
        ],
        [
            'global_phone_display',
            'Phone number shown',
            'text',
            '9990 8292'
        ],
        [
            'global_phone_href',
            'Phone link',
            'text',
            '+35699908292'
        ],
        [
            'global_whatsapp_href',
            'WhatsApp number',
            'text',
            '35699908292'
        ],
        [
            'global_email',
            'Email address',
            'email',
            'info@polariswellbeing.com'
        ],
        [
            'global_form_recipient',
            'Form recipient email',
            'email',
            'info@polariswellbeing.com'
        ],
        [
            'global_emergency_text',
            'Urgent-support note',
            'textarea',
            'This service is not for emergencies. In an immediate emergency, call 112.'
        ],
        [
            'global_privacy_consent',
            'Form consent text',
            'textarea',
            'I consent to Polaris Wellbeing using these details to respond to my enquiry. I understand that this form is not for emergencies and I should not include highly sensitive clinical information.'
        ]
    ],
    'home' => [
        [
            'home_hero_eyebrow',
            'Hero eyebrow',
            'text',
            'Come in. Take a seat.'
        ],
        [
            'home_hero_heading',
            'Hero heading',
            'textarea',
            'Your life is connected. Your care should be too.'
        ],
        [
            'home_hero_lead',
            'Hero introduction',
            'textarea',
            'Tell us what matters to you. We bring therapy, BrainGym, assessment and specialist support together in one relaxed, welcoming place.'
        ],
        [
            'home_hero_primary',
            'Hero primary button',
            'text',
            'Talk to our team'
        ],
        [
            'home_hero_secondary',
            'Hero secondary link',
            'text',
            'See what we offer'
        ],
        [
            'home_hero_promise',
            'Hero promise',
            'text',
            'Initial Wellbeing Consultation within 48 hours of booking.'
        ],
        [
            'home_hero_mobile_image',
            'Hero mobile image',
            'media',
            ''
        ],
        [
            'home_hero_desktop_image',
            'Hero desktop image',
            'media',
            ''
        ],
        [
            'home_offer_eyebrow',
            'Offer eyebrow',
            'text',
            'What we offer'
        ],
        [
            'home_offer_heading',
            'Offer heading',
            'textarea',
            'What brings you to Polaris?'
        ],
        [
            'home_offer_lead',
            'Offer introduction',
            'textarea',
            'Come with a clear idea, a question, or simply something you would like to explore. We will help you find a useful place to begin.'
        ],
        [
            'home_offer_footer',
            'Offer footer link',
            'text',
            'View everything we offer'
        ],
        [
            'home_conversation_eyebrow',
            'Conversation eyebrow',
            'text',
            'Your first conversation'
        ],
        [
            'home_conversation_heading',
            'Conversation heading',
            'textarea',
            'It starts with a conversation.'
        ],
        [
            'home_conversation_lead',
            'Conversation introduction',
            'textarea',
            'Tell us a little about what you are looking for. We will make time to listen, talk through the options and agree the next step with you.'
        ],
        [
            'home_step_1_title',
            'Step 1 title',
            'text',
            'Say hello'
        ],
        [
            'home_step_1_text',
            'Step 1 text',
            'textarea',
            'Message or call us in whichever way feels easiest.'
        ],
        [
            'home_step_2_title',
            'Step 2 title',
            'text',
            'Have a conversation'
        ],
        [
            'home_step_2_text',
            'Step 2 text',
            'textarea',
            'Meet with a wellbeing specialist within 48 hours of booking.'
        ],
        [
            'home_step_3_title',
            'Step 3 title',
            'text',
            'Take it from there'
        ],
        [
            'home_step_3_text',
            'Step 3 text',
            'textarea',
            'Together, we agree the person or combination of support that makes sense.'
        ],
        [
            'home_why_eyebrow',
            'Why Polaris eyebrow',
            'text',
            'Why Polaris'
        ],
        [
            'home_why_heading',
            'Why Polaris heading',
            'textarea',
            'Different expertise. One welcoming place.'
        ],
        [
            'home_why_lead',
            'Why Polaris introduction',
            'textarea',
            'The person in front of us matters more than the label on the door. Sometimes one professional is exactly right. Sometimes another perspective adds something useful. Either way, the care stays connected.'
        ],
        [
            'home_people_label',
            'People label',
            'text',
            'Meet some of the people behind Polaris'
        ],
        [
            'home_trust_1_title',
            'Trust point 1 title',
            'text',
            'People first'
        ],
        [
            'home_trust_1_text',
            'Trust point 1 text',
            'textarea',
            'We begin with you, not a predetermined pathway.'
        ],
        [
            'home_trust_2_title',
            'Trust point 2 title',
            'text',
            'A connected team'
        ],
        [
            'home_trust_2_text',
            'Trust point 2 text',
            'textarea',
            'Different professionals can work together when that is useful.'
        ],
        [
            'home_trust_3_title',
            'Trust point 3 title',
            'text',
            'BrainGym'
        ],
        [
            'home_trust_3_text',
            'Trust point 3 text',
            'textarea',
            'qEEG and neurofeedback are available as part of the wider Polaris offering.'
        ],
        [
            'home_trust_4_title',
            'Trust point 4 title',
            'text',
            'A thoughtful first step'
        ],
        [
            'home_trust_4_text',
            'Trust point 4 text',
            'textarea',
            'Your Initial Wellbeing Consultation can take place within 48 hours.'
        ],
        [
            'home_lower_image',
            'Lower homepage image',
            'media',
            ''
        ],
        [
            'home_final_eyebrow',
            'Final invitation eyebrow',
            'text',
            'You are welcome here'
        ],
        [
            'home_final_heading',
            'Final invitation heading',
            'textarea',
            'Come and have a conversation with us.'
        ],
        [
            'home_final_lead',
            'Final invitation text',
            'textarea',
            'Whether you already know what you are looking for or simply want to explore the options, our team will help you find an appropriate next step.'
        ]
    ],
    'how-we-can-help' => [
        [
            'help_hero_eyebrow',
            'Hero eyebrow',
            'text',
            'How we can help'
        ],
        [
            'help_hero_heading',
            'Hero heading',
            'textarea',
            'What would you like to explore?'
        ],
        [
            'help_hero_lead',
            'Hero introduction',
            'textarea',
            'You do not need to translate your life into a service name before you speak to us. Start with what matters to you, and we will help you look at the options.'
        ],
        [
            'help_main_eyebrow',
            'Main eyebrow',
            'text',
            'Explore the options'
        ],
        [
            'help_main_heading',
            'Main heading',
            'textarea',
            'Support for the person, not just the problem.'
        ],
        [
            'help_main_lead',
            'Main introduction',
            'textarea',
            'Polaris brings together therapy, assessment, BrainGym, developmental support, medical and complementary expertise. The right starting point depends on the individual.'
        ],
        [
            'help_final_eyebrow',
            'Final eyebrow',
            'text',
            'A simple first step'
        ],
        [
            'help_final_heading',
            'Final heading',
            'textarea',
            'Not sure which route fits?'
        ],
        [
            'help_final_lead',
            'Final text',
            'textarea',
            'That is exactly what the Initial Wellbeing Consultation is for. Come and talk it through with us.'
        ]
    ],
    'braingym' => [
        [
            'bg_hero_eyebrow',
            'Hero eyebrow',
            'text',
            'BrainGym at Polaris'
        ],
        [
            'bg_hero_heading',
            'Hero heading',
            'textarea',
            'Another way to look at how the brain is working.'
        ],
        [
            'bg_hero_lead',
            'Hero introduction',
            'textarea',
            'BrainGym brings qEEG brain mapping and EEG-based neurofeedback into the wider Polaris offering, giving the team an additional perspective when it is relevant to the individual.'
        ],
        [
            'bg_hero_image',
            'Hero image',
            'media',
            ''
        ],
        [
            'bg_main_eyebrow',
            'Main eyebrow',
            'text',
            'The two main services'
        ],
        [
            'bg_main_heading',
            'Main heading',
            'textarea',
            'Measure. Understand. Train.'
        ],
        [
            'bg_main_lead',
            'Main introduction',
            'textarea',
            'BrainGym should never be presented as a brain map containing every answer. It is one source of information and one form of training, interpreted in the context of the whole person.'
        ],
        [
            'bg_qeeg_title',
            'qEEG title',
            'text',
            'qEEG Brain Mapping'
        ],
        [
            'bg_qeeg_text',
            'qEEG description',
            'textarea',
            'EEG records electrical activity from the scalp. qEEG applies quantitative analysis to features of that recording so an appropriately trained professional can examine patterns in the data. It does not establish a diagnosis by itself.'
        ],
        [
            'bg_qeeg_link',
            'qEEG link label',
            'text',
            'Ask about qEEG ↗'
        ],
        [
            'bg_nf_title',
            'Neurofeedback title',
            'text',
            'Neurofeedback'
        ],
        [
            'bg_nf_text',
            'Neurofeedback description',
            'textarea',
            'Neurofeedback uses selected features of EEG activity to provide real-time visual or auditory feedback during training. Programmes are considered in relation to the individual and their wider support.'
        ],
        [
            'bg_nf_link',
            'Neurofeedback link label',
            'text',
            'Ask about neurofeedback ↗'
        ],
        [
            'bg_wider_eyebrow',
            'Wider section eyebrow',
            'text',
            'Part of something wider'
        ],
        [
            'bg_wider_heading',
            'Wider section heading',
            'textarea',
            'BrainGym sits inside Polaris, not beside it.'
        ],
        [
            'bg_wider_text',
            'Wider section text',
            'textarea',
            'Where useful, BrainGym can be considered alongside therapy, assessment, personal history, goals and other professional perspectives. The technology adds information. The person remains central.'
        ],
        [
            'bg_final_eyebrow',
            'Final eyebrow',
            'text',
            'Ask us anything'
        ],
        [
            'bg_final_heading',
            'Final heading',
            'textarea',
            'Curious about BrainGym?'
        ],
        [
            'bg_final_text',
            'Final text',
            'textarea',
            'Start with a straightforward conversation. We will explain what it involves and whether it may be relevant to what you are exploring.'
        ]
    ],
    'our-approach' => [
        [
            'approach_hero_eyebrow',
            'Hero eyebrow',
            'text',
            'Our approach'
        ],
        [
            'approach_hero_heading',
            'Hero heading',
            'textarea',
            'One person. More than one perspective.'
        ],
        [
            'approach_hero_lead',
            'Hero introduction',
            'textarea',
            'Life does not arrive in separate boxes. Thoughts, emotions, relationships, development, health, environment and goals can all affect one another. Our job is to keep the person in view.'
        ],
        [
            'approach_main_eyebrow',
            'Main eyebrow',
            'text',
            'Care that stays connected'
        ],
        [
            'approach_main_heading',
            'Main heading',
            'textarea',
            'The right amount of support, not the greatest amount.'
        ],
        [
            'approach_main_lead',
            'Main introduction',
            'textarea',
            'Sometimes one professional and one good relationship are exactly what is needed. Sometimes another perspective genuinely adds value. Polaris makes both possible without asking you to navigate a collection of disconnected services.'
        ],
        [
            'approach_point_1_title',
            'Point 1 title',
            'text',
            'We listen first'
        ],
        [
            'approach_point_1_text',
            'Point 1 text',
            'textarea',
            'We begin with what matters to you, rather than a predetermined package.'
        ],
        [
            'approach_point_2_title',
            'Point 2 title',
            'text',
            'We bring in expertise thoughtfully'
        ],
        [
            'approach_point_2_text',
            'Point 2 text',
            'textarea',
            'Another professional is involved only when there is a clear reason for it.'
        ],
        [
            'approach_point_3_title',
            'Point 3 title',
            'text',
            'We keep the picture together'
        ],
        [
            'approach_point_3_text',
            'Point 3 text',
            'textarea',
            'Where you consent to coordinated care, the relevant people can communicate rather than working in isolation.'
        ],
        [
            'approach_image',
            'Approach image',
            'media',
            ''
        ],
        [
            'approach_final_eyebrow',
            'Final eyebrow',
            'text',
            'Begin with a conversation'
        ],
        [
            'approach_final_heading',
            'Final heading',
            'textarea',
            'Come as you are.'
        ],
        [
            'approach_final_text',
            'Final text',
            'textarea',
            'You do not need to select the perfect service before you contact us. Tell us what you are looking for and we will explore the options with you.'
        ]
    ],
    'our-team' => [
        [
            'team_hero_eyebrow',
            'Hero eyebrow',
            'text',
            'Our team'
        ],
        [
            'team_hero_heading',
            'Hero heading',
            'textarea',
            'People you can feel comfortable talking to.'
        ],
        [
            'team_hero_lead',
            'Hero introduction',
            'textarea',
            'Polaris brings together professionals with different backgrounds and ways of working. Expertise matters. So does being listened to, respected and treated as a whole person.'
        ],
        [
            'team_kicker',
            'Team section label',
            'text',
            'A selection from the Polaris team'
        ],
        [
            'team_note',
            'Team note',
            'textarea',
            'This is a selection from the wider Polaris team. Talk to us about the experience or approach you are looking for.'
        ],
        [
            'team_final_eyebrow',
            'Final eyebrow',
            'text',
            'You do not need to choose alone'
        ],
        [
            'team_final_heading',
            'Final heading',
            'textarea',
            'Tell us who you would feel comfortable meeting.'
        ],
        [
            'team_final_text',
            'Final text',
            'textarea',
            'You can ask about a particular professional, or let the client care team help you find someone whose experience and approach fit what you are looking for.'
        ]
    ],
    'about-polaris' => [
        [
            'about_hero_eyebrow',
            'Hero eyebrow',
            'text',
            'About Polaris'
        ],
        [
            'about_hero_heading',
            'Hero heading',
            'textarea',
            'A different kind of place to talk, understand and grow.'
        ],
        [
            'about_hero_lead',
            'Hero introduction',
            'textarea',
            'Polaris was created around a simple observation: no single way of working is right for every person, and good support should not feel fragmented or impersonal.'
        ],
        [
            'about_main_eyebrow',
            'Main eyebrow',
            'text',
            'Why we exist'
        ],
        [
            'about_main_heading',
            'Main heading',
            'textarea',
            'Bring the perspectives together. Keep the person at the centre.'
        ],
        [
            'about_paragraph_1',
            'Paragraph 1',
            'textarea',
            'In private practice, founder Cher Engerer Kerr saw that one therapeutic toolkit could never fit everyone. When another kind of expertise was needed, people were often left to find separate professionals and connect the pieces themselves.'
        ],
        [
            'about_paragraph_2',
            'Paragraph 2',
            'textarea',
            'Polaris was built so different professionals could work alongside one another in a comfortable, down-to-earth environment. Sometimes that means one professional. Sometimes it means several perspectives. The point is not to make care more complicated. It is to make it more joined up.'
        ],
        [
            'about_paragraph_3',
            'Paragraph 3',
            'textarea',
            'That principle still shapes Polaris today.'
        ],
        [
            'about_image',
            'About image',
            'media',
            ''
        ]
    ],
    'talk-to-our-team' => [
        [
            'contact_hero_eyebrow',
            'Hero eyebrow',
            'text',
            'A simple first step'
        ],
        [
            'contact_hero_heading',
            'Hero heading',
            'textarea',
            'How would you like to talk?'
        ],
        [
            'contact_hero_lead',
            'Hero introduction',
            'textarea',
            'Choose whatever feels easiest. You can ask about a particular service, arrange an Initial Wellbeing Consultation, or simply tell us what you would like to explore.'
        ],
        [
            'contact_promise',
            'Promise',
            'text',
            'Initial Wellbeing Consultation within 48 hours of booking.'
        ],
        [
            'contact_card_1_title',
            'Card 1 title',
            'text',
            'Initial Consultation'
        ],
        [
            'contact_card_1_text',
            'Card 1 text',
            'textarea',
            'Request a focused first conversation with a wellbeing specialist.'
        ],
        [
            'contact_card_2_title',
            'Card 2 title',
            'text',
            'WhatsApp us'
        ],
        [
            'contact_card_2_text',
            'Card 2 text',
            'textarea',
            'Message the client care team directly.'
        ],
        [
            'contact_card_3_title',
            'Card 3 title',
            'text',
            'Call us'
        ],
        [
            'contact_card_3_text',
            'Card 3 text',
            'textarea',
            'Speak to the team during reception hours.'
        ],
        [
            'contact_card_4_title',
            'Card 4 title',
            'text',
            'Send a message'
        ],
        [
            'contact_card_4_text',
            'Card 4 text',
            'textarea',
            'Leave your details and preferred contact method.'
        ],
        [
            'contact_form_eyebrow',
            'Form eyebrow',
            'text',
            'Send us a message'
        ],
        [
            'contact_form_heading',
            'Form heading',
            'textarea',
            'Tell us how to reach you.'
        ],
        [
            'contact_form_help',
            'Form guidance',
            'textarea',
            'Keep this first message brief. Please do not include highly sensitive medical or clinical information.'
        ],
        [
            'contact_form_button',
            'Form button',
            'text',
            'Send message'
        ]
    ]
];
