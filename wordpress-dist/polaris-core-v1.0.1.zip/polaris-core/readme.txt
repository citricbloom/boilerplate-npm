=== Polaris Core ===
Requires at least: 6.4
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later

Structured content and enquiry handling for the Polaris Wellbeing theme.
