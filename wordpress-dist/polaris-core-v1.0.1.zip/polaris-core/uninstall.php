<?php
// Content is deliberately retained on uninstall to avoid accidental data loss.
