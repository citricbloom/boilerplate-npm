jQuery(function($){
  $('.polaris-select-media').on('click', function(){
    const id=$(this).data('target');
    const frame=wp.media({title:'Choose an image',button:{text:'Use this image'},multiple:false});
    frame.on('select',function(){const attachment=frame.state().get('selection').first().toJSON();$('#'+id).val(attachment.id);$('#'+id).siblings('.polaris-media-preview').html('<img src="'+attachment.url+'" alt="">');});
    frame.open();
  });
  $('.polaris-clear-media').on('click',function(){const id=$(this).data('target');$('#'+id).val('');$('#'+id).siblings('.polaris-media-preview').html('<span>Using the approved theme image</span>');});
});
